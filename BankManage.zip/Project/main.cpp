#include <iostream>
#include <fstream>
#include "headers\Bank.h"
using namespace std;

int main()
{
    Bank mainBank;
    mainBank.readEmployeefile();
    mainBank.readClientfile();
    mainBank.readAccountfile();
    int menu;
    do
    {
        cout << "1- Employee\n2- Clinet\n3- out\n";
        cout << "--------------\n";
        cin >> menu;
        
        if (menu == 1)
        {
            cout << "enter username : ";
            string username, password;
            cin >> username;
            cout << "enter password : ";
            cin >> password;
            for (int i = 0; i < mainBank.getEmployees().size(); i++)
            {
                if (username == mainBank.getEmployees()[i].get_username() && password == mainBank.getEmployees()[i].get_password())
                {
                    ofstream file("report.txt", ios::app);
                    if (file)
                    {
                        time_t now = time(0);
                        tm *ltm = localtime(&now);
                        file << "Employee with national code " << mainBank.getEmployees()[i].get_employee_id() << " ";
                        file << "login in date " << 1 + ltm->tm_mon << '/' << ltm->tm_mday << '/' << 1900 + ltm->tm_year << " ";
                        file << "time " <<  ltm->tm_hour << ":" <<  ltm->tm_min << '\n';
                        mainBank.employee_menu(i);
                        file.close();
                    }

                    break;
                }
            }
        }
        else if (menu == 2)
        {
            cout << "enter username : ";
            string username, password;
            cin >> username;
            cout << "enter password : ";
            cin >> password;
            for (int i = 0; i < mainBank.getClients().size(); i++)
            {
                if (username == mainBank.getClients()[i].get_username() && password == mainBank.getClients()[i].get_password())
                {
                    ofstream file("report.txt", ios::app);
                    if (file)
                    {
                        time_t now = time(0);
                        tm *ltm = localtime(&now);
                        file << "Client with national code " << mainBank.getEmployees()[i].get_employee_id() << " ";
                        file << "login in date " << 1 + ltm->tm_mon << '/' << ltm->tm_mday << '/' << 1900 + ltm->tm_year << " ";
                        file << "time " <<  ltm->tm_hour << ":" <<  ltm->tm_min << '\n';
                        mainBank.client_menu(i);
                        file.close();
                    }

                    break;
                }
            }
        }
    } while (menu != 3);
    mainBank.writeEmployeefile();
    mainBank.writeAccountfile();
    mainBank.writeClientfile();
    system("pause");
    return 0;
}

/* Error List :
114 - file could not opened
505 - the powers are not equal
501 - not found
*/
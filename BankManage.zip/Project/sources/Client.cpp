#include "..\headers\Client.h"
void Client::print_information()
{
    cout << "name : " << Fname << " " << Lname << endl;
    for (auto account : accounts)
    {
        cout << "account id : " << account.get_account_Id() << endl;
        cout << "balance : " << account.get_balance() << endl;
        cout << "is active : " << account.get_is_active() << endl;
        cout << endl;
    }
    system("pause");
    system("cls");
}
void Client::up_balance()
{
    int n;
    do
    {
        for (int i = 0; i < accounts.size(); i++)
        {
            cout << i + 1 << "- " << accounts[i].get_account_Id() << endl;
        }
        cout << "choose your account : ";
        cin >> n;
    } while (n < 0 || n > accounts.size());
    cout << "balance  : " << accounts[n - 1].get_balance() << endl;
    cout << "enter how many you wnat to increase : ";
    long long temp;
    cin >> temp;

    accounts[n - 1].set_balance(accounts[n - 1].get_balance() + temp);

    ofstream file("report.txt", ios::app);
    if (file)
    {
        time_t now = time(0);
        tm *ltm = localtime(&now);
        file << "Account with id " << accounts[n - 1].get_account_Id();
        file << " increase account balance with amount " << temp << ' ';
        file << "in date " << 1 + ltm->tm_mon << '/' << ltm->tm_mday << '/' << 1900 + ltm->tm_year << " ";
        file << "time " <<  ltm->tm_hour << ":" <<  ltm->tm_min << '\n';
        file.close();
    }
    else
    {
        cout << "the file could not be opened\n";
    }

    system("cls");
    cout << "Done\n";
}
void Client::down_balance()
{
    int n;
    do
    {
        for (int i = 0; i < accounts.size(); i++)
        {
            cout << i + 1 << "- " << accounts[i].get_account_Id() << endl;
        }
        cout << "choose your account : ";
        cin >> n;
    } while (n < 0 || n > accounts.size());

    cout << "balance  : " << accounts[n - 1].get_balance() << endl;
    if (accounts[n - 1].get_is_active() == "yes")
    {

                cout
            << "enter how many you wnat : ";
        long long temp;
        cin >> temp;
        if (temp > accounts[n - 1].get_balance())
        {
            cout << "you cant" << endl;
        }
        else
        {
            accounts[n - 1].set_balance(accounts[n - 1].get_balance() - temp);
            ofstream file("report.txt", ios::app);
            if (file)
            {
                time_t now = time(0);
                tm *ltm = localtime(&now);
                file << "Account with id " << accounts[n - 1].get_account_Id();
                file << " decreased account balance with amount " << temp << ' ';
                file << "in date " << 1 + ltm->tm_mon << '/' << ltm->tm_mday << '/' << 1900 + ltm->tm_year << " ";
                file << "time " <<  ltm->tm_hour << ":" <<  ltm->tm_min << '\n';
                file.close();
            }
            else
            {
                cout << "the file could not be opened\n";
            }
        }
    }
    else
    {
        system("cls");
        cout << "not active" << endl;
    }
}
#include "..\headers\Employee.h"
void Employee::vacation_registration()
{
    cout << "your vacation(h) : " << vacation << endl;
    cout << "how many you want : ";
    int temp;
    cin >> temp;
    if ((vacation - temp) < 0)
    {
        cout << "this will cost you : " << -(vacation - temp) * 100;
        vacation -= temp;
        salary -= (-(vacation - temp)) * 100;
        cout << "salary : " << salary << endl;
    }
    else
    {
        vacation -= temp;
        cout << "your vacation(h) : " << vacation << endl;
    }

    ofstream file("report.txt", ios::app);
    if (file)
    {
        time_t now = time(0);
        tm *ltm = localtime(&now);
        file << "Employee with national code " << employee_id;
        file << " get " << temp;
        file << " days rest in date " << 1 + ltm->tm_mon << '/' << ltm->tm_mday << '/' << 1900 + ltm->tm_year << " ";
        file << "time " <<  ltm->tm_hour << ":" <<  ltm->tm_min << '\n';
        file.close();
    }
    else
    {
        cout << "the file could not be opened\n";
    }
}
void Employee::overtime_registration()
{
    cout << "The hours you can choose for overtime : " << overtime << endl;
    int temp;
    cout << "chose : ";
    cin >> temp;
    if (overtime - temp > 0)
    {
        overtime -= temp;
        salary += (temp * 120);
        cout << "salary : " << salary << endl;
    }
    else
    {
        cout << "you cant" << endl;
    }
}
void Employee::print_information()
{
    cout << "employee id : " << employee_id << endl;
    cout << "birthday : " << born.year << '\\' << born.month << '\\' << born.day << endl;
    cout << "salary : " << salary << endl;
    cout << "vacation : " << vacation << "   overtime : " << overtime << endl;
}

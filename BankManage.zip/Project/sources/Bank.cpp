#include "..\headers\Bank.h"
#include <stdlib.h>
#include <fstream>
Bank::Bank()
{
    // Employee manger;
    // manger.set_borDate(1382, 2, 30);
    // manger.set_fname("taha");
    // manger.set_employee_id(100);
    // manger.set_lname("gholipour");
    // manger.set_manager("yes");
    // manger.set_password("1234");
    // manger.set_username("tahagho");
    // employees.push_back(manger);
}
int Bank::findClient_id(string id)
{

    int find = -1;
    for (int i = 0; i < clients.size(); i++)
    {
        if (id == clients[i].get_person_id())
        {
            find = i;
            break;
        }
    }
    return find;
}

int Bank::findEmployee_id(int id)
{
    int find = -1;
    for (int i = 0; i < employees.size(); i++)
    {
        if (employees[i].get_employee_id() == id)
        {
            find = i;
            break;
        }
    }
    return find;
}

void Bank::add_client()
{
    string id;
    Account new_account;
    cout << "enter clinet personal id : ";
    cin >> id;
    if (findClient_id(id) == -1)
    {
        Client ob;
        string temp, temp2, temp3;
        cout << "new client\n";

        cout << "enter name and family : ";
        cin >> temp >> temp2;
        ob.set_fname(temp);
        ob.set_lname(temp2);

        bool find = false;
        do
        {
            find = false;
            cout << "enter username : ";
            cin >> temp;
            for (auto client : clients)
            {
                if (client.get_username() == temp)
                {
                    find = true;
                }
            }
        } while (find);
        ob.set_username(temp);

        cout << "enter password : ";
        cin >> temp;
        ob.set_password(temp);
        int t1, t2, t3;
        cout << "enter birth year : ";
        cin >> t1;
        cout << "enter birth mounth : ";
        cin >> t2;
        cout << "enter birth day : ";
        cin >> t3;
        ob.set_borDate(t1, t2, t3);

        ob.set_person_id(id);

        new_account.set_person_id(ob.get_person_id());

        srand(time(0));
        bool find2;
        long id;
        do
        {
            find2 = false;
            id = (rand() % 888888) + 111111;
            for (auto client : clients)
            {
                for (auto account : client.get_accounts())
                {
                    if (id == account.get_account_Id())
                    {
                        find2 = true;
                    }
                }
            }
        } while (find2);

        new_account.set_account_Id(id);

        long long balance;
        do
        {
            cout << "enter initial balance : ";
            cin >> balance;
        } while (balance < 50000);
        new_account.set_balance(balance);

        time_t now = time(0);
        tm *ltm = localtime(&now);
        new_account.set_begDate(1900 + ltm->tm_year, 1 + ltm->tm_mon, ltm->tm_mday);
        ob.set_account(new_account);

        clients.push_back(ob);
    }
    else
    {
        Account new_account;
        new_account.set_person_id(clients[findClient_id(id)].get_person_id());

        bool find;
        long id2;
        do
        {
            find = false;
            id2 = (rand() % 888888) + 111111;
            for (auto client : clients)
            {
                for (auto account : client.get_accounts())
                {
                    if (id2 == account.get_account_Id())
                    {
                        find = true;
                    }
                }
            }
        } while (find);

        new_account.set_account_Id(id2);

        long long balance;
        do
        {
            cout << "enter initial balance : ";
            cin >> balance;
        } while (balance < 50000);
        new_account.set_balance(balance);

        time_t now = time(0);
        tm *ltm = localtime(&now);
        new_account.set_begDate(1900 + ltm->tm_year, 1 + ltm->tm_mon, ltm->tm_mday);
        clients[findClient_id(id)].set_account(new_account);
    }

    ofstream file("report.txt", ios::app);
    if (file)
    {
        time_t now = time(0);
        tm *ltm = localtime(&now);
        file << "Account with id  " << new_account.get_account_Id() << " ";
        file << "Create in date " << 1 + ltm->tm_mon << '/' << ltm->tm_mday << '/' << 1900 + ltm->tm_year << " ";
        file << "time " << ltm->tm_hour << ":" <<  ltm->tm_min << '\n';
        file.close();
    }
    else
    {
        cout << "the file could not be opened\n";
    }

    system("cls");
}

void Bank::delete_client()
{
    string id;
    cout << "enter clinet personal id : ";
    cin >> id;
    if (findClient_id(id) == -1)
    {
        cout << "not found\n";
    }
    else
    {
        if (clients[findClient_id(id)].get_accounts().size() == 1)
        {
            clients.erase(clients.begin() + findClient_id(id));
            cout << "done\n";
        }
        else
        {

            clients[findClient_id(id)].print_information();
            cout << "\nchosee one of them you want delete : ";
            int i;
            cin >> i;

            clients[findClient_id(id)].get_accounts().erase(clients[findClient_id(id)].get_accounts().begin() + i);
            cout << "done \n";
        }
    }
}

void Bank::add_employee()
{
    Employee ob;
    string temp;
    cout << "enter name : ";
    cin >> temp;
    ob.set_fname(temp);
    cout << "enter family : ";
    cin >> temp;
    ob.set_lname(temp);

    int y, m, d;
    cout << "enter birth year : ";
    cin >> y;
    cout << "enter birth month : ";
    cin >> m;
    cout << "enter birth day : ";
    cin >> d;
    ob.set_borDate(y, m, d);

    bool find;
    do
    {
        find = false;
        cout << "enter username : ";
        cin >> temp;
        for (auto employee : employees)
        {
            if (employee.get_username() == temp)
            {
                find = true;
            }
        }
    } while (find);
    ob.set_username(temp);

    cout << "enter password : ";
    cin >> temp;
    ob.set_password(temp);

    srand(time(0));
    int id;
    bool find2;
    do
    {
        find2 = false;
        id = (rand() % 899) + 100;
        for (int i = 0; i < employees.size(); i++)
        {
            if (id == employees[i].get_employee_id())
            {
                find2 = true;
            }
        }

    } while (find2);

    ob.set_employee_id(id);

    employees.push_back(ob);
    system("cls");
}

void Bank::delte_employee()
{
    int id;
    cout << "enter employee id : ";
    cin >> id;
    if (findEmployee_id(id) == -1)
    {
        system("cls");
        cout << "not found\n";
    }
    else
    {
        employees.erase(employees.begin() + findEmployee_id(id));
        system("cls");
        cout << "done\n";
    }
}

void Bank::deactivate_active_account()
{
    system("cls");
    int menu;
    do
    {
        cout <<"1- active\n2-deactive\n3-out\n";
        cout << "----------\n";
        cin >> menu;
    } while (menu != 3);

    cout << "enter account id : ";
    long long id;
    cin >> id;
    bool find = false;
    for (auto client : clients)
    {
        for (auto account : client.get_accounts())
        {
            if (id == account.get_account_Id())
            {
                if (menu == 1)
                {
                    account.set_is_active("yes");
                }
                else
                {
                    account.set_is_active("no");
                    ofstream file("report.txt", ios::app);
                    if (file)
                    {
                        time_t now = time(0);
                        tm *ltm = localtime(&now);
                        file<<"Account with id "<<account.get_account_Id()<<" ";
                        file << "banned in date " << 1 + ltm->tm_mon << '/' << ltm->tm_mday << '/' << 1900 + ltm->tm_year << " ";
                        file << "time " <<  ltm->tm_hour << ":" <<  ltm->tm_min << '\n';
                        file.close();
                    }
                    else
                    {
                        cout << "the file could not be opened\n";
                    }
                }

                find = true;
            }
        }
    }
    if (find)
    {
        system("cls");
        cout << "done\n";
    }
    else
    {
        cout << "not found\n";
    }
}

void Bank::client_menu(int index)
{
    int menu;
    do
    {
        cout << "1- Increase account balance\n2- decrease account balance\n";
        cout << "3- print information\n4- quit\n";
        cout << "---------------\n";
        cin >> menu;
        system("cls");
        if (menu == 1)
        {
            system("cls");
            clients[index].up_balance();
        }
        else if (menu == 2)
        {
            clients[index].down_balance();
        }
        else if (menu == 3)
        {
            clients[index].print_information();
        }

    } while (menu != 4);
}

void Bank::employee_menu(int index)
{
    int menu;
    do
    {
        cout << "1- vacation request\n2- overtime request\n3- print personal information\n";
        cout << "4- print client information\n5- add an account for clinet\n";
        cout << "6- delete an account for clinet\n10- active ot deactive an account\n";
        if (employees[index].get_is_manager() == "yes")
        {
            cout << "7- print employee information\n8- Hire an employee\n9- Fire an employee";
        }
        cout << "\n11- out";
        cout << "\n-----------------------\n";
        cin >> menu;
        system("cls");
        if (menu == 1)
        {
            employees[index].vacation_registration();
        }
        else if (menu == 2)
        {
            employees[index].overtime_registration();
        }
        else if (menu == 3)
        {
            employees[index].print_information();
        }
        else if (menu == 4)
        {
            string id;
            cout << "enter clinet personal id : ";
            cin >> id;
            int find = -1;
            for (int i = 0; i < clients.size(); i++)
            {
                if (id == clients[i].get_person_id())
                {
                    find = i;
                    break;
                }
            }
            if (find == -1)
            {
                cout << "not found\n";
            }
            else
            {
                clients[find].print_information();
            }
        }
        else if (menu == 5)
        {
            add_client();
        }
        else if (menu == 6)
        {
            delete_client();
        }
        else if (menu == 7 && employees[index].get_is_manager() == "yes")
        {
            cout << "enter employee id : ";
            int id;
            cin >> id;
            if (findEmployee_id(id) == -1)
            {
                cout << "not found\n";
            }
            else
            {
                employees[findEmployee_id(id)].print_information();
            }
        }
        else if (menu == 8 && employees[index].get_is_manager() == "yes")
        {
            add_employee();
        }
        else if (menu == 9 && employees[index].get_is_manager() == "yes")
        {
            delte_employee();
        }
        else if (menu == 10)
        {
            deactivate_active_account();
        }

    } while (menu != 11);
}

void Bank ::readEmployeefile()
{
    ifstream iFile("employees.txt");
    if (iFile)
    {
        while (!iFile.eof())
        {
            Employee ob;
            string temp;
            iFile >> temp;
            ob.set_fname(temp);
            iFile >> temp;
            ob.set_lname(temp);
            long long intTemp;
            iFile >> intTemp;
            ob.set_employee_id(intTemp);
            iFile >> temp;
            ob.set_username(temp);
            iFile >> temp;
            ob.set_password(temp);
            iFile >> intTemp;
            ob.set_salary(intTemp);
            iFile >> intTemp;
            ob.set_vacation(intTemp);
            iFile >> intTemp;
            ob.set_overtime(intTemp);
            date d;
            iFile >> d.year;
            iFile >> d.month;
            iFile >> d.day;
            ob.set_borDate(d.year, d.month, d.day);
            iFile >> temp;
            ob.set_manager(temp);
            employees.push_back(ob);
        }
        employees.pop_back();
        iFile.close();
    }
}
void Bank::writeEmployeefile()
{
    ofstream oFile("employees.txt", ios::trunc);
    if (oFile)
    {
        for (int i = 0; i < employees.size(); i++)
        {
            oFile << employees[i].get_fname() << " ";
            oFile << employees[i].get_lname() << " ";
            oFile << employees[i].get_employee_id() << " ";
            oFile << employees[i].get_username() << " ";
            oFile << employees[i].get_password() << " ";
            oFile << employees[i].get_salary() << " ";
            oFile << employees[i].get_vacatino() << " ";
            oFile << employees[i].get_overtime() << " ";
            oFile << employees[i].get_bornDate().year << " ";
            oFile << employees[i].get_bornDate().month << " ";
            oFile << employees[i].get_bornDate().day << " ";
            oFile << employees[i].get_is_manager() << " ";
            if (employees.size() - 1 != i)
            {
                oFile << '\n';
            }
        }
        oFile.close();
    }
    else
    {
        cout << "the file could not be opened\n";
    }
}

void Bank::readAccountfile()
{
    ifstream iFile("accounts.txt");
    if (iFile)
    {
        vector<Account> accounts;
        while (!iFile.eof())
        {
            Account ob;
            long id;
            iFile >> id;
            ob.set_account_Id(id);
            iFile >> id;
            ob.set_balance(id);
            string str;
            iFile >> str;
            ob.set_is_active(str);
            iFile >> str;
            ob.set_person_id(str);
            date d;
            iFile >> d.year;
            iFile >> d.month;
            iFile >> d.day;
            ob.set_begDate(d.year, d.month, d.day);
            accounts.push_back(ob);
        }
        accounts.pop_back();
        iFile.close();

        for (auto account : accounts)
        {
            for (auto &client : clients)
            {
                if (account.get_person_Id() == client.get_person_id())
                {
                    client.set_account(account);
                }
            }
        }
    }
    else
    {
        cout << "the file could not be opened\n";
    }
}
void Bank::writeAccountfile()
{
    ofstream oFile("accounts.txt", ios::trunc);
    if (oFile)
    {
        for (auto client : clients)
        {
            for (auto account : client.get_accounts())
            {
                oFile << account.get_account_Id() << ' ';
                oFile << account.get_balance() << ' ';
                oFile << account.get_is_active() << ' ';
                oFile << account.get_person_Id() << ' ';
                oFile << account.getBegDate().year << ' ';
                oFile << account.getBegDate().month << ' ';
                oFile << account.getBegDate().day << ' ';
                oFile << '\n';
            }
        }

        oFile.close();
    }
    else
    {
        cout << "the file could not be opened\n";
    }
}

void Bank::readClientfile()
{
    ifstream iFile("clients.txt");
    if (iFile)
    {
        while (!iFile.eof())
        {
            Client ob;

            string temp;
            iFile >> temp;
            ob.set_fname(temp);

            iFile >> temp;
            ob.set_lname(temp);

            iFile >> temp;
            ob.set_person_id(temp);

            date d;
            iFile >> d.year;
            iFile >> d.month;
            iFile >> d.day;
            ob.set_borDate(d.year, d.month, d.day);

            iFile >> temp;
            ob.set_username(temp);

            iFile >> temp;
            ob.set_password(temp);

            clients.push_back(ob);
        }
        clients.pop_back();
    }
    else
    {
        cout << "the file could not be opened\n";
    }
}
void Bank::writeClientfile()
{
    ofstream oFile("clients.txt", ios::trunc);
    if (oFile)
    {
        for (auto client : clients)
        {
            oFile << client.get_fname() << " ";
            oFile << client.get_lname() << " ";
            oFile << client.get_person_id() << " ";
            oFile << client.get_bornDate().year << " ";
            oFile << client.get_bornDate().month << " ";
            oFile << client.get_bornDate().day << " ";
            oFile << client.get_username() << " ";
            oFile << client.get_password() << "\n";
        }
        oFile.close();
    }
    else
    {
        cout << "the file could not be opened\n";
    }
}
#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <iostream>
#include <vector>
#include <ctime>
#include <fstream>
using namespace std;

struct date
{
    int year  , month , day ;
};
class Account
{
private:
    long account_Id;
    string person_id;
    date begDate;
    long long balance = 0;
    string is_active = "yes";

public:
    void set_account_Id(long x) { account_Id = x; }
    void set_person_id(string a) { person_id = a; }
    void set_begDate(int y, int m, int d)
    {
        begDate.year = y, begDate.day = d, begDate.month = m;
    }
    void set_balance(long long a) { balance = a; }
    void set_is_active(string a) { is_active = a; }
    long get_account_Id() { return account_Id; }
    string get_person_Id() { return person_id; }
    date getBegDate() { return begDate; }
    long long get_balance() { return balance; }
    string get_is_active() { return is_active; }
    
    Account() {}
    ~Account() {}
};


#endif // ACCOUNT_H

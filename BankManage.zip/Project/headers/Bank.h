#ifndef BANK_H
#define BANK_H

#include <ctime>
#include "..\headers\Employee.h"
#include "..\headers\Client.h"

using namespace std;

class Bank
{
private:
    vector<Employee> employees;
    vector<Client> clients;

public:
    Bank();
    vector<Employee> getEmployees() { return employees; }
    vector<Client> getClients() { return clients; }

    int findClient_id(string);
    int findEmployee_id(int);
    void client_menu(int);
    void employee_menu(int);
    void add_client();
    void delete_client();
    void add_employee();
    void delte_employee();
    void deactivate_active_account();

    void readEmployeefile();
    void writeEmployeefile();

    void readAccountfile();
    void writeAccountfile();

    void readClientfile();
    void writeClientfile();

    ~Bank() {}
};

#endif // BANK_H

#ifndef CLIENT_H
#define CLIENT_H

#include "..\headers\Account.h"
using namespace std;

class Client
{
private:
    string Fname, Lname;
    string person_id;
    date born;
    string username;
    string password;
    vector<Account> accounts;

public:
    void set_fname(string str) { Fname = str; }
    void set_lname(string str) { Lname = str; }
    void set_person_id(string str) { person_id = str; }
    void set_username(string str) { username = str; }
    void set_password(string str) { password = str; }
    void set_borDate(int y, int m, int d)
    {
        born.year = y, born.day = d, born.month = m;
    }
    void set_account(Account &ob) { accounts.push_back(ob); }

    string get_fname() { return Fname; }
    string get_lname() { return Lname; }
    string get_person_id() { return person_id; }
    string get_username() { return username; }
    string get_password() { return password; }
    date get_bornDate() { return born; }
    vector<Account> get_accounts() { return accounts; }
   
    void print_information();
    void up_balance();
    void down_balance();
   
    Client(/* args */) {}
    ~Client() {}
};

#endif // CLIENT_H
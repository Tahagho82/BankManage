#ifndef EMPLOYEE_
#define EMPLOYEE_H

#include <iostream>
#include <fstream>
#include "..\headers\Client.h"
using namespace std;
class Employee
{
private:
    
    int overtime = 12, vacation = 15;
    long long salary = 0;
    string Fname, Lname;
    int employee_id;
    date born;
    string username;
    string password;
    string is_manager="no";

public:
    void set_fname(string str) { Fname = str; }
    void set_lname(string str) { Lname = str; }
    void set_employee_id(int id) { employee_id =id ; }
    void set_username(string str) { username = str; }
    void set_password(string str) { password = str; }
    void set_borDate(int y, int m, int d)
    {
        born.year = y, born.day = d, born.month = m;
    }
    void set_salary(long long a) { salary = a; }
    void set_vacation(int a) { vacation = a; }
    void set_overtime(int a) { overtime = a; }
    void set_manager(string a){is_manager=a;}

    string get_is_manager(){return is_manager;}
    string get_fname() { return Fname; }
    string get_lname() { return Lname; }
    int get_employee_id() { return employee_id; }
    string get_username() { return username; }
    string get_password() { return password; }
    date get_bornDate() { return born; }
    long long get_salary(){return salary;}
    int get_vacatino(){return vacation;}
    int get_overtime(){return overtime;}

    void vacation_registration();
    void overtime_registration();
    void print_information();
    
    Employee(/* args */) {}
    ~Employee() {}
};

#endif // EMPLOYEE_H
